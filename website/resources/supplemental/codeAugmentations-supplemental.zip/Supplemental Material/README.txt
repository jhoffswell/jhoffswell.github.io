There are 13 files in the ZIP of supplementary material. 5 PDF files
contain the materials used for the evaluation, including the interview
script, instruction sheets, task questions, and post-task questionnaire.
The 5 .vg.json files contain the Vega code used for the evaluation tasks
and training. The .r file contains our analysis procedure. The .sbv file 
contains the captions for the preview video (updated Jan. 22). The last 
file is this one (the README).