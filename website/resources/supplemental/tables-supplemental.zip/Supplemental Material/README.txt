This directory contains the supplemental material for the paper "Interactive Repair of Tables Extracted from PDF Documents on Mobile Devices." Here is a brief description of the supplemental material:

-- analysis.R
The script used to perform the statistical analysis for the paper.

-- choice-actions.csv
Each action performed by the study participants when participants could choose which technique to use (either gesture or toolbar).

-- ComputedFeatures.pdf
The list of features computed for our analysis pipeline.

-- EvaluationScript.pdf
The script used by the authors when conducting the evaluation of our table editing techniques.

-- Post-StudyQuestionnaire.pdf
The questions asked in the post-study questionnaire for the evaluation of our table editing techniques.

-- survey-data.csv
The data collected during the post-task questionnaire. Used by the analysis.R script to produce the statistical results for the paper.

-- user-study-data.csv
The data collection during the evaluation, which includes the device used, the technique used, the file, the number of actions performed, the time spent on the actions, the percent of the actions that used the gesture technique, and the type of condition that participants completed second (e.g., gesture or toolbar). Used by the analysis.R script to produce the statistical results for the paper.