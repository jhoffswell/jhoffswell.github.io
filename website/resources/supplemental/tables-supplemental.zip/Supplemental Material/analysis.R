library(lme4)
library(multcomp)

# Read in the original user study data.
d <- read.csv('user-study-data.csv')
d = d[d$File!='Training',]

d$Subject <- as.factor(d$ID)
d$LogTime <- log10(d$Time)
summary(d)

# Create a dataset containing only the data for the "Choice" condition.
c <- d[d$Condition=='Choice',]
summary(c)

# Create a dataset containing only the data for the "Toolbar" and "Gesture" conditions.
e <- d[d$Condition!='Choice',]
summary(e)

##############################################################################
################################ Action Model ################################
##############################################################################

# Model for the number of actions performed for the toolbar/gesture condition.

am <- lmer(Actions ~ Condition + Device + log10(Order) + (Condition|Subject) + (1|File), e)
drop1(am, test="Chisq")
# Single term deletions
# Model:
# Actions ~ Condition + Device + log10(Order) + (Condition | Subject) +  (1 | File)
#              Df    AIC    LRT  Pr(Chi)   
# <none>          931.93                   
# Condition     1 939.31 9.3809 0.002193 **
# Device        1 929.99 0.0616 0.803965   
# log10(Order)  1 931.48 1.5509 0.213003   
# ---
# Signif. codes:  0 ‘***’ 0.001 ‘**’ 0.01 ‘*’ 0.05 ‘.’ 0.1 ‘ ’ 1

summary(am)
# Linear mixed model fit by REML ['lmerMod']
# Formula: Actions ~ Condition + Device + log10(Order) + (Condition | Subject) + (1 | File)
#    Data: e
#
# REML criterion at convergence: 892.4
#
# Scaled residuals: 
#     Min      1Q  Median      3Q     Max 
# -1.6719 -0.5077 -0.1411  0.1624  5.1102 
#
# Random effects:
#  Groups   Name             Variance Std.Dev. Corr 
#  Subject  (Intercept)      211.2    14.53         
#           ConditionToolbar 111.4    10.55    -1.00
#  File     (Intercept)      128.0    11.32         
#  Residual                  356.5    18.88         
# Number of obs: 102, groups:  Subject, 17; File, 6
#
# Fixed effects:
#                  Estimate Std. Error t value
# (Intercept)        38.320      9.437   4.061
# ConditionToolbar  -15.619      4.546  -3.436
# DeviceTablet        1.225      5.149   0.238
# log10(Order)      -15.611     10.339  -1.510
#
# Correlation of Fixed Effects:
#             (Intr) CndtnT DvcTbl
# ConditnTlbr -0.331              
# DeviceTablt -0.227 -0.039       
# log10(Ordr) -0.686 -0.046 -0.058

##############################################################################
################################# Time Model #################################
##############################################################################

# Model for the log time taken for the toolbar/gesture condition.
 
tm <- lmer(LogTime ~ Condition + Device + log10(Order) + (Condition|Subject) + (1|File), e)
drop1(tm, test="Chisq")
# Single term deletions
# Model:
# LogTime ~ Condition + Device + log10(Order) + (Condition | Subject) + (1 | File)
#              Df    AIC     LRT   Pr(Chi)    
# <none>          119.63                      
# Condition     1 138.70 21.0717 4.424e-06 ***
# Device        1 117.71  0.0746    0.7847    
# log10(Order)  1 138.12 20.4899 5.995e-06 ***
# ---
# Signif. codes:  0 ‘***’ 0.001 ‘**’ 0.01 ‘*’ 0.05 ‘.’ 0.1 ‘ ’ 1

summary(tm)
# Linear mixed model fit by REML ['lmerMod']
# Formula: LogTime ~ Condition + Device + log10(Order) + (Condition | Subject) + (1 | File)
#    Data: e
#
# REML criterion at convergence: 110.6
#
# Scaled residuals: 
#      Min       1Q   Median       3Q      Max 
# -2.05372 -0.51909  0.04096  0.63191  2.28538 
#
# Random effects:
#  Groups   Name             Variance Std.Dev. Corr
#  Subject  (Intercept)      0.022493 0.14998      
#           ConditionToolbar 0.003784 0.06152  1.00
#  File     (Intercept)      0.356621 0.59718      
#  Residual                  0.110733 0.33277      
# Number of obs: 102, groups:  Subject, 17; File, 6
#
# Fixed effects:
#                  Estimate Std. Error t value
# (Intercept)       5.64746    0.27747  20.353
# ConditionToolbar -0.38066    0.06787  -5.608
# DeviceTablet     -0.02778    0.10463  -0.266
# log10(Order)     -0.96312    0.17148  -5.617
#
# Correlation of Fixed Effects:
#             (Intr) CndtnT DvcTbl
# ConditnTlbr -0.057              
# DeviceTablt -0.162 -0.054       
# log10(Ordr) -0.385 -0.050 -0.057

##############################################################################
################################ Choice Model ################################
##############################################################################

# Model for the percentage gestures used in the choice condition.

pm <- lmer(PercentGesture ~ Device + (Device | Subject) + (1|File), c)
drop1(pm, test="Chisq")
# Single term deletions
# Model:
# PercentGesture ~ Device + (Device | Subject) + (1 | File)
#        Df    AIC     LRT Pr(Chi)
# <none>    655.74                
# Device  1 653.87 0.12114  0.7278

# Model for the percentage gestures used in the choice condition, based on the
# previously completed condition (gesture/toolbar); check for priming effect.

pm2 <- lmer(PercentGesture ~ Device + SecondCondition + (Device|Subject) + (1|File), c)
drop1(pm2, test="Chisq")
# Single term deletions
# Model:
# PercentGesture ~ Device + SecondCondition + (Device | Subject) + (1 | File)
#                 Df    AIC    LRT  Pr(Chi)   
# <none>             650.66                   
# Device           1 648.74 0.0812 0.775671   
# SecondCondition  1 655.74 7.0866 0.007766 **
# ---
# Signif. codes:  0 ‘***’ 0.001 ‘**’ 0.01 ‘*’ 0.05 ‘.’ 0.1 ‘ ’ 1

summary(pm2)
# Linear mixed model fit by REML ['lmerMod']
# Formula: PercentGesture ~ Device + SecondCondition + (Device | Subject) + (1 | File)
#    Data: c
#
# REML criterion at convergence: 617
#
# Scaled residuals: 
#      Min       1Q   Median       3Q      Max 
# -1.79254 -0.57603  0.05338  0.60988  2.00635 
#
# Random effects:
#  Groups   Name         Variance Std.Dev. Corr
#  Subject  (Intercept)  365.55   19.119       
#           DeviceTablet 205.32   14.329   0.41
#  File     (Intercept)   51.63    7.185       
#  Residual              380.62   19.509       
# Number of obs: 68, groups:  Subject, 17; File, 4
#
# Fixed effects:
#                        Estimate Std. Error t value
# (Intercept)              62.315      9.039   6.894
# DeviceTablet             -1.624      5.967  -0.272
# SecondConditionToolbar  -35.852     11.471  -3.125
#
# Correlation of Fixed Effects:
#             (Intr) DvcTbl
# DeviceTablt -0.089       
# ScndCndtnTl -0.654 -0.032

##############################################################################
################################ Survey Data #################################
##############################################################################

sd <- read.csv('survey-data.csv')

tabletFirst = sd[sd$Tablet_First==1,]
phoneFirst = sd[sd$Tablet_First==0,]
toolbarFirst = sd[sd$Toolbar_First==1,]
gestureFirst = sd[sd$Toolbar_First==0,]

################################## Identify ##################################

wilcox.test(sd$Identify, mu=3, conf.int=TRUE)
# data:  sd$Identify
# V = 5.5, p-value = 0.003557
# alternative hypothesis: true location is not equal to 3
# 95 percent confidence interval:
#  1.499998 2.000024
# sample estimates:
# (pseudo)median 
#       1.999976 

wilcox.test(tabletFirst$Identify, phoneFirst$Identify, paired=FALSE)
# data:  tabletFirst$Identify and phoneFirst$Identify
# W = 49, p-value = 0.1883
# alternative hypothesis: true location shift is not equal to 0

wilcox.test(toolbarFirst$Identify, gestureFirst$Identify, paired=FALSE)
# data:  toolbarFirst$Identify and gestureFirst$Identify
# W = 15.5, p-value = 0.03528
# alternative hypothesis: true location shift is not equal to 0

#################################### Fix #####################################

wilcox.test(sd$Fix, mu=3, conf.int=TRUE)
data:  sd$Fix
# V = 8.5, p-value = 0.09182
# alternative hypothesis: true location is not equal to 3
# 95 percent confidence interval:
#  1.500046 3.499988
# sample estimates:
# (pseudo)median 
#              2 

wilcox.test(tabletFirst$Fix, phoneFirst$Fix, paired=FALSE)
# data:  tabletFirst$Fix and phoneFirst$Fix
# W = 42, p-value = 0.5609
# alternative hypothesis: true location shift is not equal to 0

wilcox.test(toolbarFirst$Fix, gestureFirst$Fix, paired=FALSE)
# data:  toolbarFirst$Fix and gestureFirst$Fix
# W = 45, p-value = 0.3689
# alternative hypothesis: true location shift is not equal to 0

############################## Easier_Gesture ################################

wilcox.test(sd$Easier_Gesture, mu=3, conf.int=TRUE)
# data:  sd$Easier_Gesture
# V = 18, p-value = 0.01334
# alternative hypothesis: true location is not equal to 3
# 95 percent confidence interval:
#  1.499963 2.999962
# sample estimates:
# (pseudo)median 
#       1.999969 

wilcox.test(tabletFirst$Easier_Gesture, phoneFirst$Easier_Gesture, paired=FALSE)
# data:  tabletFirst$Easier_Gesture and phoneFirst$Easier_Gesture
# W = 26, p-value = 0.3295
# alternative hypothesis: true location shift is not equal to 0

wilcox.test(toolbarFirst$Easier_Gesture, gestureFirst$Easier_Gesture, paired=FALSE)
# data:  toolbarFirst$Easier_Gesture and gestureFirst$Easier_Gesture
# W = 50.5, p-value = 0.1507
# alternative hypothesis: true location shift is not equal to 0

############################## Faster_Gesture ################################

wilcox.test(sd$Faster_Gesture, mu=3, conf.int=TRUE)
# data:  sd$Faster_Gesture
# V = 51, p-value = 0.3792
# alternative hypothesis: true location is not equal to 3
# 95 percent confidence interval:
#  1.500010 3.500047
# sample estimates:
# (pseudo)median 
#       2.500045 

wilcox.test(tabletFirst$Faster_Gesture, phoneFirst$Faster_Gesture, paired=FALSE)
# data:  tabletFirst$Faster_Gesture and phoneFirst$Faster_Gesture
# W = 24.5, p-value = 0.2743
# alternative hypothesis: true location shift is not equal to 0

wilcox.test(toolbarFirst$Faster_Gesture, gestureFirst$Faster_Gesture, paired=FALSE)
# data:  toolbarFirst$Faster_Gesture and gestureFirst$Faster_Gesture
# W = 51.5, p-value = 0.136
# alternative hypothesis: true location shift is not equal to 0

############################### Easier_Phone #################################

wilcox.test(sd$Easier_Phone, mu=3, conf.int=TRUE)
# data:  sd$Easier_Phone
# V = 22, p-value = 0.01487
# alternative hypothesis: true location is not equal to 3
# 95 percent confidence interval:
#  1.000000 2.999969
# sample estimates:
# (pseudo)median 
#       1.500022 

wilcox.test(tabletFirst$Easier_Phone, phoneFirst$Easier_Phone, paired=FALSE)
# data:  tabletFirst$Easier_Phone and phoneFirst$Easier_Phone
# W = 34, p-value = 0.8751
# alternative hypothesis: true location shift is not equal to 0

wilcox.test(toolbarFirst$Easier_Phone, gestureFirst$Easier_Phone, paired=FALSE)
# data:  toolbarFirst$Easier_Phone and gestureFirst$Easier_Phone
# W = 38, p-value = 0.8751
# alternative hypothesis: true location shift is not equal to 0

############################### Easier_Tablet ################################

wilcox.test(sd$Easier_Tablet, mu=3, conf.int=TRUE)
# data:  sd$Easier_Tablet
# V = 47.5, p-value = 0.4743
# alternative hypothesis: true location is not equal to 3
# 95 percent confidence interval:
#  1.000075 3.999969
# sample estimates:
# (pseudo)median 
#        2.99998

wilcox.test(tabletFirst$Easier_Tablet, phoneFirst$Easier_Tablet, paired=FALSE)
# data:  tabletFirst$Easier_Tablet and phoneFirst$Easier_Tablet
# W = 22, p-value = 0.174
# alternative hypothesis: true location shift is not equal to 0

wilcox.test(toolbarFirst$Easier_Tablet, gestureFirst$Easier_Tablet, paired=FALSE)
# data:  toolbarFirst$Easier_Tablet and gestureFirst$Easier_Tablet
# W = 55, p-value = 0.06245
# alternative hypothesis: true location shift is not equal to 0

############################### Prefer_Tablet ################################

wilcox.test(sd$Prefer_Tablet, mu=3, conf.int=TRUE)
# data:  sd$Prefer_Tablet
# V = 122, p-value = 0.00392
# alternative hypothesis: true location is not equal to 3
# 95 percent confidence interval:
#  3.500007 5.000000
# sample estimates:
# (pseudo)median 
#       4.500007 

wilcox.test(tabletFirst$Prefer_Tablet, phoneFirst$Prefer_Tablet, paired=FALSE)
# data:  tabletFirst$Prefer_Tablet and phoneFirst$Prefer_Tablet
# W = 42, p-value = 0.5504
# alternative hypothesis: true location shift is not equal to 0

wilcox.test(toolbarFirst$Prefer_Tablet, gestureFirst$Prefer_Tablet, paired=FALSE)
# data:  toolbarFirst$Prefer_Tablet and gestureFirst$Prefer_Tablet
# W = 32.5, p-value = 0.7446
# alternative hypothesis: true location shift is not equal to 0
