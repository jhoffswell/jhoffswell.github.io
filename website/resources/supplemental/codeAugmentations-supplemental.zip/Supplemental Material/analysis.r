library(lme4)

d <- read.csv('aggregate.csv')
d$Subject <- as.factor(d$ID)
d$LogTime <- log10(d$Time)

## GRADE MODEL
gm <- lmer(Grade ~ Condition + Order + (1|Subject) + (1|Position), d)

drop1(gm, test="Chisq")
# Single term deletions
#
# Model:
# Grade ~ Condition + Order + (1 | Subject) + (1 | Position)
#           Df    AIC    LRT Pr(Chi)
# <none>       224.11
# Condition  1 225.42 3.3086 0.06892 .
# Order      1 224.81 2.6955 0.10063
# ---
# Signif. codes:  0 ‘***’ 0.001 ‘**’ 0.01 ‘*’ 0.05 ‘.’ 0.1 ‘ ’ 1

summary(gm)
# Linear mixed model fit by REML ['lmerMod']
# Formula: Grade ~ Condition + Order + (1 | Subject) + (1 | Position)
#    Data: d
#
# REML criterion at convergence: 205
#
# Scaled residuals:
#      Min       1Q   Median       3Q      Max
# -1.54924 -0.47095  0.06636  0.49822  1.64765
#
# Random effects:
#  Groups   Name        Variance Std.Dev.
#  Subject  (Intercept)  8.866   2.978
#  Position (Intercept) 11.595   3.405
#  Residual             12.424   3.525
# Number of obs: 36, groups:  Subject, 18; Position, 5
#
# Fixed effects:
#                        Estimate Std. Error t value
# (Intercept)              19.615      2.582   7.597
# Conditionvisualization    2.111      1.175   1.797
# Order                     1.889      1.175   1.608
#
# Correlation of Fixed Effects:
#             (Intr) Cndtnv
# Cndtnvslztn -0.228
# Order       -0.683  0.000

## TIME MODEL
tm <- lmer(LogTime ~ Condition + Order + (1|Subject) + (1|Position), d)

drop1(tm, test="Chisq")
# Single term deletions
#
# Model:
# LogTime ~ Condition + Order + (1 | Subject) + (1 | Position)
#           Df     AIC    LRT  Pr(Chi)
# <none>       -3.1505
# Condition  1 -5.1032 0.0473 0.827743
# Order      1  3.8100 8.9605 0.002759 **
# ---
# Signif. codes:  0 ‘***’ 0.001 ‘**’ 0.01 ‘*’ 0.05 ‘.’ 0.1 ‘ ’ 1

summary(tm)
# Linear mixed model fit by REML ['lmerMod']
# Formula: LogTime ~ Condition + Order + (1 | Subject) + (1 | Position)
#    Data: d
#
# REML criterion at convergence: -2.9
#
# Scaled residuals:
#     Min      1Q  Median      3Q     Max
# -1.6685 -0.5565 -0.0373  0.2137  3.8792
#
# Random effects:
#  Groups   Name        Variance Std.Dev.
#  Subject  (Intercept) 0.00731  0.0855
#  Position (Intercept) 0.00000  0.0000
#  Residual             0.03527  0.1878
# Number of obs: 36, groups:  Subject, 18; Position, 5
#
# Fixed effects:
#                        Estimate Std. Error t value
# (Intercept)             6.54331    0.10575   61.87
# Conditionvisualization -0.01285    0.06260   -0.21
# Order                  -0.20063    0.06260   -3.20
#
# Correlation of Fixed Effects:
#             (Intr) Cndtnv
# Cndtnvslztn -0.296
# Order       -0.888  0.000

## CONFIDENCE MODEL
cm <- lmer(Confidence ~ Condition + Order + (1|Subject) + (1|Position), d)

drop1(cm, test="Chisq")
# Single term deletions
#
# Model:
# Confidence ~ Condition + Order + (1 | Subject) + (1 | Position)
#           Df    AIC     LRT Pr(Chi)
# <none>       82.180
# Condition  1 80.253 0.07345  0.7864
# Order      1 80.999 0.81933  0.3654

summary(cm)
# Linear mixed model fit by REML ['lmerMod']
# Formula: Confidence ~ Condition + Order + (1 | Subject) + (1 | Position)
#    Data: d
#
# REML criterion at convergence: 76.1
#
# Scaled residuals:
#      Min       1Q   Median       3Q      Max
# -1.40602 -0.57680 -0.00019  0.54626  1.44398
#
# Random effects:
#  Groups   Name        Variance Std.Dev.
#  Subject  (Intercept) 0.57515  0.7584
#  Position (Intercept) 0.09253  0.3042
#  Residual             0.14756  0.3841
# Number of obs: 36, groups:  Subject, 18; Position, 2
#
# Fixed effects:
#                        Estimate Std. Error t value
# (Intercept)             3.27011    0.36176   9.039
# Conditionvisualization  0.03275    0.12805   0.256
# Order                   0.11053    0.12805   0.863
#
# Correlation of Fixed Effects:
#             (Intr) Cndtnv
# Cndtnvslztn -0.177
# Order       -0.531  0.000

## SURVEY RESPONSES
sd <- read.csv('survey.csv')

wilcox.test(sd$Quickly, mu=4, conf.int=TRUE)
# 	Wilcoxon signed rank test with continuity correction
# data:  sd$Quickly
# V = 127, p-value = 0.002018
# alternative hypothesis: true location is not equal to 4
# 95 percent confidence interval:
#  4.999945 6.000046
# sample estimates:
# (pseudo)median
#       5.499993

wilcox.test(sd$Accurate, mu=4, conf.int=TRUE)
# 	Wilcoxon signed rank test with continuity correction
# data:  sd$Accurate
# V = 112, p-value = 0.002602
# alternative hypothesis: true location is not equal to 4
# 95 percent confidence interval:
#  4.500042 6.000000
# sample estimates:
# (pseudo)median
#       5.499932

wilcox.test(sd$Helpful..Value, mu=3, conf.int=TRUE)
# 	Wilcoxon signed rank test with continuity correction
# data:  sd$Helpful..Value
# V = 42, p-value = 0.5153
# alternative hypothesis: true location is not equal to 3
# 95 percent confidence interval:
#  1.500029 3.999926
# sample estimates:
# (pseudo)median
#       2.999951

wilcox.test(sd$Helpful..Indicator, mu=3, conf.int=TRUE)
# 	Wilcoxon signed rank test with continuity correction
# data:  sd$Helpful..Indicator
# V = 47.5, p-value = 0.913
# alternative hypothesis: true location is not equal to 3
# 95 percent confidence interval:
#  1.500047 4.500012
# sample estimates:
# (pseudo)median
#        3.00002

wilcox.test(sd$Helpful..Line, mu=3, conf.int=TRUE)
# 	Wilcoxon signed rank test with continuity correction
# data:  sd$Helpful..Line
# V = 112, p-value = 0.002602
# alternative hypothesis: true location is not equal to 3
# 95 percent confidence interval:
#  3.500042 5.000000
# sample estimates:
# (pseudo)median
#       4.499932

wilcox.test(sd$Helpful..Tick, mu=3, conf.int=TRUE)
# 	Wilcoxon signed rank test with continuity correction
# data:  sd$Helpful..Tick
# V = 59.5, p-value = 0.3296
# alternative hypothesis: true location is not equal to 3
# 95 percent confidence interval:
#  2.500013 4.500015
# sample estimates:
# (pseudo)median
#       3.500005

wilcox.test(sd$Helpful..Histogram, mu=3, conf.int=TRUE)
# 	Wilcoxon signed rank test with continuity correction
# data:  sd$Helpful..Histogram
# V = 79, p-value = 0.09312
# alternative hypothesis: true location is not equal to 3
# 95 percent confidence interval:
#  2.999977 4.500023
# sample estimates:
# (pseudo)median
#       4.000029

wilcox.test(sd$Interpretable..Value, mu=3, conf.int=TRUE)
# 	Wilcoxon signed rank test with continuity correction
# data:  sd$Interpretable..Value
# V = 89, p-value = 0.001507
# alternative hypothesis: true location is not equal to 3
# 80 percent confidence interval:
#  4.500028 5.000000
# sample estimates:
# (pseudo)median
#       4.999927

wilcox.test(sd$Interpretable..Indicator, mu=3, conf.int=TRUE)
# 	Wilcoxon signed rank test with continuity correction
# data:  sd$Interpretable..Indicator
# V = 81.5, p-value = 0.01036
# alternative hypothesis: true location is not equal to 3
# 95 percent confidence interval:
#  3.999979 5.000000
# sample estimates:
# (pseudo)median
#       4.500022

wilcox.test(sd$Interpretable..Line, mu=3, conf.int=TRUE)
# 	Wilcoxon signed rank test with continuity correction
# data:  sd$Interpretable..Line
# V = 118, p-value = 0.007611
# alternative hypothesis: true location is not equal to 3
# 95 percent confidence interval:
#  3.499986 4.500081
# sample estimates:
# (pseudo)median
#       4.000062

wilcox.test(sd$Interpretable..Tick, mu=3, conf.int=TRUE)
# 	Wilcoxon signed rank test with continuity correction
# data:  sd$Interpretable..Tick
# V = 41, p-value = 0.1735
# alternative hypothesis: true location is not equal to 3
# 95 percent confidence interval:
#  2.500048 5.000000
# sample estimates:
# (pseudo)median
#       3.999957

wilcox.test(sd$Interpretable..Histogram, mu=3, conf.int=TRUE)
# 	Wilcoxon signed rank test with continuity correction
# data:  sd$Interpretable..Histogram
# V = 103, p-value = 0.06594
# alternative hypothesis: true location is not equal to 3
# 95 percent confidence interval:
#  2.999972 4.500020
# sample estimates:
# (pseudo)median
#        3.50005

wilcox.test(sd$Intrusive..Value, mu=3, conf.int=TRUE)
# 	Wilcoxon signed rank test with continuity correction
# data:  sd$Intrusive..Value
# V = 0, p-value = 0.000236
# alternative hypothesis: true location is not equal to 3
# 90 percent confidence interval:
#  1.000000 1.499985
# sample estimates:
# (pseudo)median
#        1.00007

wilcox.test(sd$Intrusive...Indicator, mu=3, conf.int=TRUE)
# 	Wilcoxon signed rank test with continuity correction
# data:  sd$Intrusive...Indicator
# V = 11, p-value = 0.002317
# alternative hypothesis: true location is not equal to 3
# 95 percent confidence interval:
#  1.000000 1.999982
# sample estimates:
# (pseudo)median
#       1.499914

wilcox.test(sd$Intrusive..Line, mu=3, conf.int=TRUE)
# 	Wilcoxon signed rank test with continuity correction
# data:  sd$Intrusive..Line
# V = 15.5, p-value = 0.004617
# alternative hypothesis: true location is not equal to 3
# 90 percent confidence interval:
#  1.000000 2.499961
# sample estimates:
# (pseudo)median
#       1.499939

wilcox.test(sd$Intrusive..Tick, mu=3, conf.int=TRUE)
# 	Wilcoxon signed rank test with continuity correction
# data:  sd$Intrusive..Tick
# V = 6, p-value = 0.0154
# alternative hypothesis: true location is not equal to 3
# 90 percent confidence interval:
#  1.00000 2.50005
# sample estimates:
# (pseudo)median
#       1.500039

wilcox.test(sd$Intrusive..Histogram, mu=3, conf.int=TRUE)
# 	Wilcoxon signed rank test with continuity correction
# data:  sd$Intrusive..Histogram
# V = 31, p-value = 0.1679
# alternative hypothesis: true location is not equal to 3
# 95 percent confidence interval:
#  1.00000 3.00002
# sample estimates:
# (pseudo)median
#       2.000048
